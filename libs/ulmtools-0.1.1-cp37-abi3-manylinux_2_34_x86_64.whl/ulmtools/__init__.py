from collections.abc import Sequence

import numpy as np

from .ulmtools import (
    rs_detect_and_localize_peaks,
    rs_detect_peaks,
    rs_detect_peaks3d,
    rs_draw_tracks,
    rs_draw_tracks_3d,
    # rs_link_points,
    rs_radial_symmetry_2d,
)

__all__ = [
    "detect_peaks",
    "detect_peaks_3d",
    "draw_tracks",
    "draw_tracks_3d",
    "radial_symmetry_2d",
    "detect_and_localize_peaks",
    # "link_points",
]


def detect_peaks(
    array: np.ndarray,
    extent: tuple | None = None,
    threshold: float = float("-inf"),
    min_distance: float = 0.0,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Find peaks in a 2D image.

    Args:
        array: 2D array-like (coerced to float32) indexed as [x, y]
        extent: Extent object or sequence of 4 floats (x0, x1, y0, y1), if not provided
            defaults to (0, shape[0]-1, 0, shape[1]-1)
        threshold: Minimum intensity for a peak
        min_distance: Minimum distance between peaks

    Returns:
        indices: Nx2 array of peak indices (x, y)

    Notes:
    - Maxima at the border of the image are ignored.
    - A peak is defined as a pixel with intensity greater than all its neighbors.
    - On equal intensities the pixel with the lowest x is chosen as higher
    - On equal intensities and x the pixel with the lowest y is chosen as higher
    """
    array = _as_c_contig(array, 2)

    extent = _extent_default_if_none(extent, array.shape)

    extent = _parse_extent(extent, 4)

    # 3. Call the Rust binary
    return rs_detect_peaks(array, extent, threshold, min_distance)


def detect_peaks_3d(
    array: np.ndarray,
    extent: tuple | None = None,
    threshold: float = float("-inf"),
    min_distance: float = 0.0,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Find peaks in a 3D image.

    Args:
        array: 3D array-like (coerced to float32) indexed as [x, y, z]
        extent: Extent object or sequence of 6 floats (x0, x1, y0, y1, z0, z1),
            defaults to (0, shape[0]-1, 0, shape[1]-1, 0, shape[2]-1) if not provided
        threshold: Minimum intensity for a peak
        min_distance: Minimum distance between peaks

    Returns:
        indices: Nx3 array of peak indices (x, y, z)

    Notes:
    - Maxima at the border of the image are ignored.
    - A peak is defined as a voxel with intensity greater than all its neighbors.
    - On equal intensities the voxel with the lowest x is chosen as higher
    - On equal intensities and x the voxel with the lowest y is chosen as higher
    - On equal intensities, x and y the voxel with the lowest z is chosen as higher
    """
    # 1. Automatic Type and Layout Conversion
    # 'C' order ensures the memory is contiguous for Rust/ndarray
    array = _as_c_contig(array, 3)

    extent = _extent_default_if_none(extent, array.shape)

    extent = _parse_extent(extent, 6)

    # 3. Call the Rust binary
    return rs_detect_peaks3d(array, extent, threshold, min_distance)


def draw_tracks(
    matrix_x_y_intensity: np.ndarray,
    track_end_indices: np.ndarray,
    extent: tuple,
    pixel_size: float = 1.0,
) -> tuple[np.ndarray, np.ndarray, tuple]:
    """
    Draw tracks on a 2D image.

    Args:
        matrix_x_y_intensity: 2D array-like (coerced to float32) of shape (N, 3) where
            each row is (x, y, intensity)
        track_end_indices: 1D array-like (coerced to int32) of indices defining where
            tracks end in matrix_x_y_intensity.
        extent: Extent object or sequence of 4 floats (x0, x1, y0, y1)
        pixel_size: Pixel size for the output image

    Returns:
        image_intensity: 2D array of drawn tracks
        image_density: 2D array of pixel counts
        extent: Tuple of (x0, x1, y0, y1) defining the extent of the output image
    """
    matrix_x_y_intensity = _as_c_contig(matrix_x_y_intensity, 2)
    track_end_indices = _as_c_contig(track_end_indices, 1, dtype=np.int32)
    if extent is None:
        extent = (
            np.min(matrix_x_y_intensity[:, 0]),
            np.max(matrix_x_y_intensity[:, 0]),
            np.min(matrix_x_y_intensity[:, 1]),
            np.max(matrix_x_y_intensity[:, 1]),
        )
    extent = _parse_extent(extent, 4)

    return rs_draw_tracks(matrix_x_y_intensity, track_end_indices, extent, pixel_size)


def draw_tracks_3d(
    matrix_x_y_z_intensity: np.ndarray,
    track_end_indices: np.ndarray,
    extent: tuple,
    pixel_size: float,
) -> tuple[np.ndarray, np.ndarray, tuple]:
    """
    Draw tracks on a 3D image.

    Args:
        matrix_x_y_z_intensity: 2D array-like (coerced to float32) of shape (N, 4) where
            each row is (x, y, z, intensity)
        track_end_indices: 1D array-like (coerced to int32) of indices defining where
            tracks end in matrix_x_y_z_intensity.
        extent: Extent object or sequence of 6 floats (x0, x1, y0, y1, z0, z1)
        pixel_size: Pixel size for the output image

    Returns:
        image_intensity: 3D array of drawn tracks
        image_density: 3D array of voxel counts
        extent: Tuple of (x0, x1, y0, y1, z0, z1) defining the extent of the output image
    """
    array = _as_c_contig(matrix_x_y_z_intensity, 2)
    track_end_indices = np.ascontiguousarray(track_end_indices, dtype=np.int32)

    extent = _parse_extent(extent, 6)

    return rs_draw_tracks_3d(array, track_end_indices, extent, pixel_size)


def radial_symmetry_2d(
    array: np.ndarray,
) -> np.ndarray:
    """
    Localize points of radial symmetry in a 2D image.
    Args:
        array: 2D array-like (coerced to float32) indexed as [x, y]
    Returns:
        output: 2D array of same shape as input with localized points of radial symmetry
    """
    arr = _as_c_contig(array, 2)

    return rs_radial_symmetry_2d(arr)


def detect_and_localize_peaks(
    array: np.ndarray,
    extent: tuple | None = None,
    threshold: float = float("-inf"),
    min_distance: float = 0.0,
    window_size: int = 5,
    max_n_peaks_per_frame: int = 100,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Find peaks in a 2D image.

    Args:
        array: 2D array-like (coerced to float32) indexed as [x, y]
        extent: Extent object or sequence of 4 floats (x0, x1, y0, y1)
        threshold: Minimum intensity for a peak
        min_distance: Minimum distance between peaks
        window_size: Size of the window for localizing peaks
        max_n_peaks_per_frame: Maximum number of peaks to return
    Returns:
        indices: Nx2 array of peak indices (x, y)
        intensities: N array of peak intensities
    Notes:
    - Maxima at the border of the image are ignored.
    - A peak is defined as a pixel with intensity greater than all its neighbors.
    - On equal intensities the pixel with the lowest x is chosen as higher
    - On equal intensities and x the pixel with the lowest y is chosen as higher
    """
    array = _as_c_contig(array, 2)

    extent = _extent_default_if_none(extent, array.shape)
    extent = _parse_extent(extent, 4)

    if window_size % 2 == 0 or window_size < 3:
        raise ValueError(
            "window_size must be an odd integer greater than or equal to 3"
        )

    max_n_peaks_per_frame = int(max_n_peaks_per_frame)
    if max_n_peaks_per_frame <= 0:
        raise ValueError("max_n_peaks_per_frame must be a positive integer")

    return rs_detect_and_localize_peaks(
        array, extent, threshold, min_distance, window_size, max_n_peaks_per_frame
    )


# def link_points(
#     points_list: Sequence[np.ndarray],
#     max_distance: float,
# ) -> list[np.ndarray]:
#     """
#     Link points across frames based on proximity.

#     Args:
#         points_list: List of 2D array-like (coerced to float32) of shape (N, 2) where
#             each row is (x, y) for each frame
#         max_distance: Maximum distance to link points between frames

#     Returns:
#         tracks: List of 2D arrays where each row is (x, y, intensity) for each track
#     """
#     points_list = [_as_c_contig(points, 2) for points in points_list]

#     return rs_link_points(points_list, max_distance)


def _as_c_contig(array: np.ndarray, ndim: int, dtype=np.float32) -> np.ndarray:
    arr = np.ascontiguousarray(array, dtype=dtype)
    if arr.ndim != ndim:
        raise ValueError(f"Expected {ndim}D image, got {arr.ndim}D")
    return arr


def _extent_default_if_none(
    extent: tuple | None, shape: tuple[int, ...]
) -> tuple[float, ...]:
    if extent is None:
        new_extent = []
        for dim_size in shape:
            new_extent.append(0.0)
            new_extent.append(float(dim_size - 1))
        return tuple(new_extent)
    return extent


def _parse_extent(extent: Sequence[float], n: int) -> tuple[float, ...]:
    if len(extent) != n:
        raise ValueError(f"extent must have length {n}, got {extent}")
    try:
        return tuple(float(v) for v in extent)
    except (TypeError, ValueError) as e:
        raise ValueError(
            f"extent must be a sequence of {n} floats, got {extent}"
        ) from e
